LibreOffice
===========

To generate `libreoffice-srcs.nix`:

    nix-shell default-gen-shell.nix --run generate

To generate `libreoffice-srcs-still.nix`:

    nix-shell still-gen-shell.nix --run generate
