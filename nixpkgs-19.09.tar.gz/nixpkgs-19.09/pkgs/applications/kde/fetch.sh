WGET_ARGS=( https://download.kde.org/stable/applications/19.08.1/ )
