WGET_ARGS=( https://download.kde.org/stable/plasma/5.16.5/ )
