export GOTOOLDIR=@bin@/bin
