* Build the RTS separately from Idris
* idris2nix
* Only require gmp, rts when compiling executables