Moved to [/doc/languages-frameworks/idris.section.md](/doc/languages-frameworks/idris.section.md)
