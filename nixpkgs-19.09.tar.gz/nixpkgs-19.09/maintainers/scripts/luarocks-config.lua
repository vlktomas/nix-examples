rocks_servers = {
	"https://luarocks.org"
}
version_check_on_fail = false
