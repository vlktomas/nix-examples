## Issue description



### Steps to reproduce



## Technical details

Please run `nix run nixpkgs.nix-info -c nix-info -m` and paste the result.
