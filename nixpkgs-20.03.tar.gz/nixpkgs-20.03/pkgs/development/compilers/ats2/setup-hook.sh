export PATSHOME=@out@/lib/ats2-postiats-@version@
