export PATSHOMERELOC=@out@/lib/ats2-postiats-@version@
