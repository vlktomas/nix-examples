WGET_ARGS=( https://download.kde.org/stable/plasma/5.17.5/ )
