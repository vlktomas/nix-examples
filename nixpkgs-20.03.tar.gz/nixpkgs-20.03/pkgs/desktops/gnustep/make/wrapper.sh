#!/bin/sh

. $GNUSTEP_MAKEFILES/GNUstep.sh
$1
