WGET_ARGS=( http://download.kde.org/stable/release-service/19.12.3/src )
